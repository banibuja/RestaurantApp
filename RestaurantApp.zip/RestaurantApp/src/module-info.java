/**
 * 
 */
/**
 * @author dell
 *
 */
module RestaurantApp {
}